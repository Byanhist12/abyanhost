
/*
*| PROJECT BETA!!
*| TQTO :
*| Affisjunianto
*| Hazn Re
*| FEBZABOTZ
*| Zeroyt7
*| Franky404
*| adiwajshing/baileys
*|┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅
*/
const
	{
		WAConnection,
		MessageType,
		Presence,
		MessageOptions,
		Mimetype,
		WALocationMessage,
		WA_MESSAGE_STUB_TYPES,
		WA_DEFAULT_EPHEMERAL,
		ReconnectMode,
		ProxyAgent,
		GroupSettingChange,
		waChatKey,
		mentionedJid,
		processTime,
	} = require("@adiwajshing/baileys")
const fs = require("fs")
const axios = require('axios')
const speed = require("performance-now")
const util = require('util')
const crypto = require('crypto')
const request = require('request')
const { exec, spawn } = require('child_process')
const fetch = require('node-fetch')
const moment = require('moment-timezone')
const ffmpeg = require('fluent-ffmpeg')
const { removeBackgroundFromImageFile } = require('remove.bg')
const { fetchJosn, fetchText } = require('./lib/fetcher')
const { color, bgcolor } = require('./lib/color')
const { wait, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, start, info, success, close } = require('./lib/functions')


owner = '6285849261085'
botname = 'CikoBot'
ownername = 'Pebkun'
cikopi = 'XChillDs'
//━━━━━━━━━━━━━━━[ DATABASE ]━━━━━━━━━━━━━━━━━//

const _antilink = JSON.parse(fs.readFileSync('./database/antilink.json'))
const _antivirtex = JSON.parse(fs.readFileSync('./database/antivirtex.json'))


module.exports = fdhl = async (fdhl, mek, _welkom) => {
	try {
        if (!mek.hasNewMessage) return
        mek = mek.messages.all()[0]
		if (!mek.message) return
		if (mek.key && mek.key.remoteJid == 'status@broadcast') return
		global.blocked
        	mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
        const content = JSON.stringify(mek.message)
		const from = mek.key.remoteJid
		const { text, extendedText, contact, contactsArray, groupInviteMessage, listMessage, buttonsMessage, location, liveLocation, image, video, sticker, document, audio, product, quotedMsg } = MessageType
		const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
        const type = Object.keys(mek.message)[0]        
        const cmd = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()
        const prefix = /^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+*@,;]/.test(cmd) ? cmd.match(/^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+*,;]/gi) : '-'          	
        body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message[type].caption.startsWith(prefix) ? mek.message[type].caption : (type == 'videoMessage') && mek.message[type].caption.startsWith(prefix) ? mek.message[type].caption : (type == 'extendedTextMessage') && mek.message[type].text.startsWith(prefix) ? mek.message[type].text : (type == 'listResponseMessage') && mek.message[type].singleSelectReply.selectedRowId ? mek.message[type].singleSelectReply.selectedRowId : (type == 'buttonsResponseMessage') && mek.message[type].selectedButtonId ? mek.message[type].selectedButtonId : ''
		budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
		const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()		
		const args = body.trim().split(/ +/).slice(1)
		const isCmd = body.startsWith(prefix)
		const q = args.join(' ')
		const Verived = "0@s.whatsapp.net"
		const txt = mek.message.conversation
		const botNumber = fdhl.user.jid
		const ownerNumber = [`${owner}@s.whatsapp.net`, `6283862323152@s.whatsapp.net`]
		const isGroup = from.endsWith('@g.us')
		let sender = isGroup ? mek.participant : mek.key.remoteJid
		const totalchat = await fdhl.chats.all()
		const groupMetadata = isGroup ? await fdhl.groupMetadata(from) : ''
		const groupName = isGroup ? groupMetadata.subject : ''
		const groupId = isGroup ? groupMetadata.jid : ''
		const groupMembers = isGroup ? groupMetadata.participants : ''
		const groupDesc = isGroup ? groupMetadata.desc : ''
		const groupOwner = isGroup ? groupMetadata.owner : ''
		const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
		const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		const isGroupAdmins = groupAdmins.includes(sender) || false
		const conts = mek.key.fromMe ? fdhl.user.jid : fdhl.contacts[sender] || { notify: jid.replace(/@.+/, '') }
        const pushname = mek.key.fromMe ? fdhl.user.name : conts.notify || conts.vname || conts.name || '-'
        
		const isAntiLink = isGroup ? _antilink.includes(from) : false
		const isWelkom = isGroup ? _welkom.includes(from) : false
		const isAntiVirtex = isGroup ? _antivirtex.includes(from) : false
		const isOwner = ownerNumber.includes(sender)
		const isMybot = isOwner || mek.key.fromMe
		
//━━━━━━━━━━━━━━━[ CONNECTION 1 ]━━━━━━━━━━━━━━━━━//

		mess = {
			wait: 'Wait... in process!',
			success: 'Done Jangan Lupa Subscribe Fadhil Graphy',
			error: {
				stick: 'Gagal Convert Gambar To Sticker...Coba Lagi!',
				Iv: 'Linknya Error Kak!'
			},
			only: {
				admin: 'Kusus Admin Kak!',
				group: 'Khusus Group Kak!'
			}
		}
		faketeks = 'Fadhil Graphy'
		const isUrl = (url) => {
        return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
        }
        const reply = (teks) => {
            fdhl.sendMessage(from, teks, text, {quoted:mek})
        }
        const sendMess = (hehe, teks) => {
            fdhl.sendMessage(hehe, teks, text)
        }
        const mentions = (teks, memberr, id) => {
            (id == null || id == undefined || id == false) ? fdhl.sendMessage(from, teks.trim(), extendedText, { contextInfo: { "mentionedJid": memberr } }) : fdhl.sendMessage(from, teks.trim(), extendedText, { quoted: ftrol, contextInfo: { "mentionedJid": memberr } })
        }
        const nigambar = fs.readFileSync ('./Arin/fdhlgrphy.jpg')
        const costum = (pesan, tipe, target, target2) => {
			fdhl.sendMessage(from, pesan, tipe, { quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target2}` } } })
		}
        
//━━━━━━━━━━━━━━━[ BUTTON BENTAR BANG ]━━━━━━━━━━━━━━━━━//

        const sendButton = async (from, context, fortext, but, mek) => {
            buttonMessages = {
                contentText: context,
                footerText: fortext,
                buttons: but,
                headerType: 1
            }
            fdhl.sendMessage(from, buttonMessages, buttonsMessage, {
                quoted: ftrol
            })
        }
        const sendButImage = async (from, context, fortext, img, but, mek) => {
            jadinya = await fdhl.prepareMessage(from, img, image)
            buttonMessagesI = {
                imageMessage: jadinya.message.imageMessage,
                contentText: context,
                footerText: fortext,
                buttons: but,
                headerType: 4
            }
            fdhl.sendMessage(from, buttonMessagesI, buttonsMessage, {
                quoted: ftrol,
                contexInfo: adyt
            })
        }
        //sendButLoc(id/from, "string", "string", image, but, mek)
         function _0x49e8(){const _0x2abf1f=['128458zaqRph','15LuvETp','32FoIOpf','By\x20:\x20Prassz','307917pLgBPR','Zerobot~Prassz','127514DLEruK','2301110zFGGkR','11iUrhyl','5IBSTLg','sendMessage','2099160NwtLDQ','672988HpVyoZ','1059558OLmAKI'];_0x49e8=function(){return _0x2abf1f;};return _0x49e8();}(function(_0x4b5fea,_0xcd96a7){const _0xd54c3c=_0x9a06,_0x555513=_0x4b5fea();while(!![]){try{const _0x4e06eb=parseInt(_0xd54c3c(0x12b))/0x1+parseInt(_0xd54c3c(0x123))/0x2*(parseInt(_0xd54c3c(0x12c))/0x3)+-parseInt(_0xd54c3c(0x129))/0x4*(parseInt(_0xd54c3c(0x126))/0x5)+-parseInt(_0xd54c3c(0x12a))/0x6+-parseInt(_0xd54c3c(0x128))/0x7+parseInt(_0xd54c3c(0x12d))/0x8*(parseInt(_0xd54c3c(0x12f))/0x9)+-parseInt(_0xd54c3c(0x124))/0xa*(-parseInt(_0xd54c3c(0x125))/0xb);if(_0x4e06eb===_0xcd96a7)break;else _0x555513['push'](_0x555513['shift']());}catch(_0x5da84c){_0x555513['push'](_0x555513['shift']());}}}(_0x49e8,0x2960e));function _0x9a06(_0x41e8cb,_0x44ab09){const _0x49e8d9=_0x49e8();return _0x9a06=function(_0x9a063c,_0x40f3e3){_0x9a063c=_0x9a063c-0x123;let _0x55b451=_0x49e8d9[_0x9a063c];return _0x55b451;},_0x9a06(_0x41e8cb,_0x44ab09);}const sendButLoc=async(_0x151338,_0x56cd7c,_0x33ce1f,_0xbff411,_0x1ecc85,_0x40a38d)=>{const _0xf018e3=_0x9a06;return buttonMessagesL={'contentText':_0x56cd7c,'footerText':_0x33ce1f,'buttons':_0x1ecc85,'headerType':0x6,'locationMessage':{'degreesLatitude':0x0,'degreesLongitude':0x0,'name':_0xf018e3(0x130),'address':_0xf018e3(0x12e),'jpegThumbnail':_0xbff411}},fdhl[_0xf018e3(0x127)](_0x151338,buttonMessagesL,buttonsMessage,{'quoted':_0x40a38d});};


//━━━━━━━━━━━━━━━[ FAKE RPLY ]━━━━━━━━━━━━━━━━━//
        const fakestatus = (teks) => {
            fdhl.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": faketeks,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./Arin/fdhl.jpg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        fdhl.chatRead(from, "read")
        const fakegroup = (teks) => {
            fdhl.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289523258649-1604595598@g.us" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": faketeks,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./Arin/fdhl.jpg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        const ftrol = {
	key : {
                          participant : '0@s.whatsapp.net'
                        },
       message: {
                    orderMessage: {
                            itemCount : 111,
                            status: 1,
                            surface : 1,
                            message: `CikoBot Whastapp Asisten\nStatus Online✓ Prefix [ # ]`, 
                            orderTitle: `CikoBot WhatsApp Asisten\nStatus Online✓ Prefix [ # ]`,
                            thumbnail: nigambar,
                            sellerJid: '0@s.whatsapp.net' 
                          }
                        }
                      }
        

        const sendStickerFromUrl = async(to, url) => {
                var names = Date.now() / 10000;
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, './stik' + names + '.png', async function () {
                    console.log('selesai');
                    let filess = './stik' + names + '.png'
                    let asw = './stik' + names + '.webp'
                    exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
                        let media = fs.readFileSync(asw)
                        fdhl.sendMessage(to, media, MessageType.sticker,{quoted:mek})
                        fs.unlinkSync(filess)
                        fs.unlinkSync(asw)
                    });
                });
            }
        const sendMediaURL = async(to, url, text="", mids=[]) =>{
                if(mids.length > 0){
                    text = normalizeMention(to, text, mids)
                }
                const fn = Date.now() / 10000;
                const filename = fn.toString()
                let mime = ""
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        mime = res.headers['content-type']
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, filename, async function () {
                    console.log('done');
                    let media = fs.readFileSync(filename)
                    let type = mime.split("/")[0]+"Message"
                    if(mime === "image/gif"){
                        type = MessageType.video
                        mime = Mimetype.gif
                    }
                    if(mime.split("/")[0] === "audio"){
                        mime = Mimetype.mp4Audio
                    }
                    fdhl.sendMessage(to, media, type, { quoted: ftrol, mimetype: mime, caption: text,contextInfo: {"mentionedJid": mids}})
                    
                    fs.unlinkSync(filename)
                });
            }   
            if (budy.includes("https://chat.whatsapp.com/")) {
if (!isGroup) return
if (!isAntiLink) return
if (isGroupAdmins) return
var kic = `${sender.split("@")[0]}@s.whatsapp.net`
reply(` *「 GROUP LINK DETECTOR 」*\nKamu mengirimkan link grup chat, maaf kamu di kick dari grup :(`)
setTimeout(() => {
fdhl.groupRemove(from, [kic]).catch((e) => { reply(`BOT HARUS JADI ADMIN`) })
}, 0)
}

		if (budy.length > 3500) {
if (!isGroup) return
if (!isAntiVirtex) return
if (isGroupAdmins) return
reply('Tandai telah dibaca\n'.repeat(300))
reply(`「 *VIRTEX DETECTOR* 」\n\nKamu mengirimkan virtex, maaf kamu di kick dari group :(`)
console.log(color('[KICK]', 'red'), color('Received a virus text!', 'yellow'))
fdhl.groupRemove(from, [sender])
}     



		colors = ['red', 'white', 'black', 'blue', 'yellow', 'green']
		const isMedia = (type === 'imageMessage' || type === 'videoMessage')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
		const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
		const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
      	if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mCIKO\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
      	//if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mTEXT\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
     	if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mCIKO\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
      	//if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mTEXT\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))

//┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅〔 MENU MSKER 〕┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅//

switch (command) {

//┅┅┅┅〔 Fitur Tambahan Dari Pebri 〕┅┅┅┅//
	
			case 'neon': 
                    if (args.length < 1) return reply(`*Example :*\n${prefix}${command} Vall Gans`)
					makell = args.join(" ")
					reply(mess.wait)
					anu = await fetchJson(`https://api-xchillds.herokuapp.com/api/textmaker/metallic?text=${makell}&theme=neon&apikey=${cikopi}`)
					buffer1 = await getBuffer(anu.result.url)
					fdhl.sendMessage(from, buffer1, image, {quoted: mek, thumbnail: fs.readFileSync('./pebrikun.jpg')})
					break //tambahin sendiri mls nambahin					


//»»»»»»»»»»»»»»»»»»»»»»|| menu ||«««««««««««««««««««««««//
            case 'menu':
menu2 = `Hi kak *${pushname}*

 ❑Group Menu
	◈ ${prefix}antilink
	◈ ${prefix}welcome
	◈ ${prefix}antivirtex
	◈ ${prefix}group
	◈ ${prefix}linkgrup
	◈ ${prefix}promote
	◈ ${prefix}demote
	◈ ${prefix}add
	◈ ${prefix}kick
	◈ ${prefix}tagall	
	◈ ${prefix}setpp
	◈ ${prefix}setdesc
	◈ ${prefix}setname
	◈ ${prefix}hidetag
	
 ❑Sticker Menu
	◈ ${prefix}attp
	◈ ${prefix}sticker
	◈ ${prefix}tomp3
	◈ ${prefix}tovideo
	
 ❑Fun Menu
    ◈ ${prefix}truth
	◈ ${prefix}dare
    ◈ ${prefix}rate
	◈ ${prefix}apakah
	◈ ${prefix}kapankah
	◈ ${prefix}bisakah
	◈ ${prefix}darkjokes	
	
 ❑Owner Menu
	◈ ${prefix}owner
	◈ ${prefix}sewabot
	◈ ${prefix}bc
	◈ ${prefix}report
	
Note : Fitur Masih Dikit Karena Masih Beta
Jangan Lupa Subscribe Fadhil Graphy

©Fadhil Graphy
©Pebkun`                  
		truteh = fs.readFileSync ('./Arin/fdhlgrphy.jpg')
		fdhl.sendMessage(from, truteh, image, { caption: 'CikoBotMenu\n\n'+ menu2, quoted: ftrol })
		
	        	break
	        	
            case 'truth':
            case 'trut':
                  if (!isGroup) return reply(mess.only.group)
                  const trut =['Pernah suka sama siapa aja? berapa lama?','Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)','apa ketakutan terbesar kamu?','pernah suka sama orang dan merasa orang itu suka sama kamu juga?','Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?','pernah gak nyuri uang nyokap atau bokap? Alesanya?','hal yang bikin seneng pas lu lagi sedih apa','pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?','pernah jadi selingkuhan orang?','hal yang paling ditakutin','siapa orang yang paling berpengaruh kepada kehidupanmu','hal membanggakan apa yang kamu dapatkan di tahun ini','siapa orang yang bisa membuatmu sange','siapa orang yang pernah buatmu sange','(bgi yg muslim) pernah ga solat seharian?','Siapa yang paling mendekati tipe pasangan idealmu di sini','suka mabar(main bareng)sama siapa?','pernah nolak orang? alasannya kenapa?','Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget','pencapaian yang udah didapet apa aja ditahun ini?','kebiasaan terburuk lo pas di sekolah apa?']
		const ttrth = trut[Math.floor(Math.random() * trut.length)]
		truteh = await getBuffer(`https://www.linkpicture.com/q/images_72.png`)
		fdhl.sendMessage(from, truteh, image, { caption: '*TRUTH*\n\n'+ ttrth, quoted: mek })
	        	break
		case 'dare':
		if (!isGroup) return reply(mess.only.group)
		const dare =['Kirim pesan ke mantan kamu dan bilang "aku masih suka sama kamu','telfon crush/pacar sekarang dan ss ke pemain','pap ke salah satu anggota grup','Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo','ss recent call whatsapp','drop emot "😎??" setiap ngetik di gc/pc selama 1 hari','kirim voice note bilang can i call u baby?','drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu','pake foto sule sampe 3 hari','ketik pake bahasa daerah 24 jam','ganti nama menjadi "gue anak lucinta luna" selama 5 jam','chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you','prank chat mantan dan bilang " i love u, pgn balikan','record voice baca surah al-kautsar','bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini','sebutkan tipe pacar mu!','snap/post foto pacar/crush','teriak gajelas lalu kirim pake vn kesini','pap mukamu lalu kirim ke salah satu temanmu','kirim fotomu dengan caption, aku anak pungut','teriak pake kata kasar sambil vn trus kirim kesini','teriak " anjimm gabutt anjimmm " di depan rumah mu','ganti nama jadi " BOWO " selama 24 jam','Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll']
		const der = dare[Math.floor(Math.random() * dare.length)]
		tod = await getBuffer(`https://www.linkpicture.com/q/images_72.png`)
		fdhl.sendMessage(from, tod, image, { quoted: mek, caption: '*DARE*\n\n'+ der })
        		break
            case 'darkjokes':
                    if (!isGroup) return reply(mess.only.group)
					let data = fs.readFileSync('./lib/darkjokes.js');
					jsonData = JSON.parse(data);
					randIndex = Math.floor(Math.random() * jsonData.length);
					randKey = jsonData[randIndex];
					hasil = await getBuffer(randKey.result)
					fdhl.sendMessage(from, hasil, image, {thumbnail: Buffer.alloc(0), quoted: mek})
					break
					//menu gabut gc
//-- ganteng cek
case 'gantengcek':
  if (args.length < 1) return reply(`Contoh : ${prefix}gantengcek pebkun`)
if (!isGroup) return reply(mess.only.group)
  random = `${Math.floor(Math.random() * 100)}`
  gan = value
  cek = `Target : *${gan}*
Persentase : ${random}%`
pebkun.sendMessage(from, cek, text, {quoted: mek})
break

//--- cantik cek
case 'cantikcek':
  if (args.length < 1) return reply(`Contoh : ${prefix}cantikcek pebkun`)
if (!isGroup) return reply(mess.only.group)
  random = `${Math.floor(Math.random() * 100)}`
  can = value
  cek = `Target : *${can}*
Persentase : ${random}%`
pebkun.sendMessage(from, cek, text, {quoted: mek})
break

//--- apakah
case 'apakah':
if (!isGroup) return reply(mess.only.group)
if (args.length < 1) return reply(`Contoh : ${prefix}apakah pebkun jelek`)
apa = value
naon = ["Iya","Tidak","Mungkin"]
random = naon[Math.floor(Math.random() * (naon.length))]
apakah = `Apakah *${apa}*
Jawaban : ${random}`
reply(apakah)
break

//--- rate
case 'rate':
if (!isGroup) return reply(mess.only.group)
if (args.length < 1) return reply(`Contoh : ${prefix}rate pebkun jelek`)
rate = value
random = `${Math.floor(Math.random() * 100)}`
rating = `Rate ${rate}
Persentase : ${random}%`
reply(rating)
break

//--- bisakah
case 'bisakah':
if (!isGroup) return reply(mess.only.group)
if (args.length < 1) return reply(`Contoh : ${prefix}bisakah pebkun terbang`)
bisa = value
naon = ["Iya","Tidak","Mungkin"]
random = naon[Math.floor(Math.random() * (naon.length))]
bisakah = `Bisakah ${bisa}
Jawaban : ${random}`
reply(bisakah)
break

//--- kapankah
case 'kapankah':
if (!isGroup) return reply(mess.only.group)
if (args.length < 1) return reply(`Contoh : ${prefix}kapankah pebkun menikah`)
kapan = value
no = `${Math.floor(Math.random() * 100)}`
naon = ["Jam lagi","Hari lagi","Minggu lagi","Bulan lagi","Tahun lagi"]
random = naon[Math.floor(Math.random() * (naon.length))]
kapan = `Kapankah ${kapan}
Jawaban : ${no} ${random}`
reply(kapan)
break		

case 'tagall':
		  if (!isGroup) return reply(mess.only.group)
			if (!isGroupAdmins) return reply(mess.only.admin)
					members_id = []
			teks = `▢ Group : *${groupName}*\n▢ Jumlah member : *${groupMetadata.participants.length}*\n\n┌───⊷ *MENTIONS* ⊶\n`
			for (let mem of groupMembers) {
						teks += `├╼ @${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
			teks += `└──────────────`
			mentions(teks, members_id, true)
			break

						
//┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅〔 FEATURE GROUP 〕┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅//

     case 'welcome':     
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (args.length < 1) return reply(`Ketik :\n${prefix}welcome on untuk mengaktifkan\n${prefix}welcome off untuk menonaktifkan`)
         if ((args[0]) === 'on') {
         if (isWelkom) return reply('welcome sudah aktif')
         _welkom.push(from)
         fs.writeFileSync('./database/welcome.json', JSON.stringify(_welkom))
         reply(`\`\`\`✓Sukses mengaktifkan fitur welcome di group\`\`\` *${groupMetadata.subject}*`)
         } else if ((args[0]) === 'off') {
         if (!isWelkom) return reply('welcome sudah off sebelumnya')
             _welkom.splice(from, 1)
         fs.writeFileSync('./database/welcome.json', JSON.stringify(_welkom))
         reply(`\`\`\`✓Sukses menonaktifkan fitur welcome di group\`\`\` *${groupMetadata.subject}*`)
         } else {
         reply('on untuk mengaktifkan, off untuk menonaktifkan')
         }
         break
     case 'antilink' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         but = [
         { buttonId: '!antilinkon', buttonText: { displayText: 'On' }, type: 1 },
         { buttonId: '!antilinkoff', buttonText: { displayText: 'Off' }, type: 1 }
         ]
         sendButton(from, "Silahkan pilih untuk antilink group", faketeks, but, mek)
         break
     case 'antilinkon' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         if (isAntiLink) return reply('anti link sudah on')
         _antilink.push(from)
         fs.writeFileSync('./database/antilink.json', JSON.stringify(_antilink))
         reply(`\`\`\`✓Sukses mengaktifkan fitur anti link di group\`\`\` *${groupMetadata.subject}*`)
         break
     case 'antilinkoff' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         if (!isAntiLink) return reply('anti link sudah off sebelumnya')
         _antilink.splice(from, 1)
         fs.writeFileSync('./database/antilink.json', JSON.stringify(_antilink))
         reply(`\`\`\`✓Sukses menonaktifkan fitur anti link di group\`\`\` *${groupMetadata.subject}*`)
         break
     case 'antivirtex' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         but = [
         { buttonId: '!antivirtexon', buttonText: { displayText: 'On' }, type: 1 },
         { buttonId: '!antivirtexoff', buttonText: { displayText: 'Off' }, type: 1 }
         ]
         sendButton(from, "Silahkan pilih untuk antivirtex group", faketeks, but, mek)
         break
     case 'antivirtexon' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         if (isAntiVirtex) return reply('anti virtex group sudah aktif sebelumnya')
         _antivirtex.push(from)
         fs.writeFileSync('./database/antivirtex.json', JSON.stringify(_antivirtex))
         reply(`\`\`\`Sukses mengaktifkan mode anti virtex di group\`\`\` *${groupMetadata.subject}*`)
         break
     case 'antivirtexoff' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         if (!isAntiVirtex) return reply('Mode anti virtex sudah nonaktif sebelumnya')
         _antivirtex.splice(from, 1)
         fs.writeFileSync('./database/antivirtex.json', JSON.stringify(_antivirtex))
         reply(`\`\`\`✓Sukes menonaktifkan mode anti virtex di group\`\`\` *${groupMetadata.subject}*`)
         break
     case 'group' :
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isGroup) return reply(mess.only.group)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         but = [
         { buttonId: '!groupbuka', buttonText: { displayText: 'Buka' }, type: 1 },
         { buttonId: '!geouptutup', buttonText: { displayText: 'Tutup' }, type: 1 }
         ]
         sendButton(from, "Silahkan pilih untuk buka/tutup group", faketeks, but, mek)
         break
     case 'groupbuka' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         reply(`\`\`\`✓Sukses Membuka Group\`\`\` *${groupMetadata.subject}*`)
         fdhl.groupSettingChange(from, GroupSettingChange.messageSend, false)
         break
     case 'grouptutup' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         reply(`\`\`\`✓Sukses Menutup Group\`\`\` *${groupMetadata.subject}*`)
         fdhl.groupSettingChange(from, GroupSettingChange.messageSend, true)
         break
     case 'linkgrup' :
         if (!isGroup) return reply(mess.only.group)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         linkgc = await fdhl.groupInviteCode(from)
         yeh = `https://chat.whatsapp.com/${linkgc}\n\nlink Group *${groupName}*`
         fdhl.sendMessage(from, yeh, text, { quoted: ftrol })
         break
     case 'promote' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di jadi admin!')
         mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
         if (mentioned.length > 1) {
         teks = 'Perintah di terima, anda menjdi admin :\n'
         for (let _ of mentioned) {
         teks += `@${_.split('@')[0]}\n`
         }
         mentions(teks, mentioned, true)
         fdhl.groupMakeAdmin(from, mentioned)
         } else {
         mentions(`Perintah di terima, @${mentioned[0].split('@')[0]} Kamu Menjadi Admin Di Group *${groupMetadata.subject}*`, mentioned, true)
         fdhl.groupMakeAdmin(from, mentioned)
         }
         break
     case 'demote' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tidak jadi admin!')
         mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
         if (mentioned.length > 1) {
         teks = 'Perintah di terima, anda tidak menjadi admin :\n'
         for (let _ of mentioned) {
         teks += `@${_.split('@')[0]}\n`
         }
         mentions(teks, mentioned, true)
         fdhl.groupDemoteAdmin(from, mentioned)
         } else {
         mentions(`Perintah di terima, Menurunkan : @${mentioned[0].split('@')[0]} Menjadi Member`, mentioned, true)
         fdhl.groupDemoteAdmin(from, mentioned)
         }
         break
     case 'add' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         if (args.length < 1) return reply('Yang mau di add siapa??')
         if (args[0].startsWith('08')) return reply('Gunakan kode negara Gan')
         try {
         num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
         fdhl.groupAdd(from, [num])
         } catch (e) {
         console.log('Error :', e)
         reply('Gagal menambahkan target, mungkin karena di private')
         }
         break
     case 'kick' :
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply("Bot Bukan Admin :)")
         if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!')
         mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
         if (mentioned.length > 1) {
         teks = 'Perintah di terima, mengeluarkan :\n'
         for (let _ of mentioned) {
         teks += `@${_.split('@')[0]}\n`
         }
         mentions(teks, mentioned, true)
         fdhl.groupRemove(from, mentioned)
         } else {
         mentions(`Perintah di terima, mengeluarkan : @${mentioned[0].split('@')[0]}`, mentioned, true)
         fdhl.groupRemove(from, mentioned)
         }
         break
     case 'tagall':
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply(mess.only.Badmin)
         members_id = []
         teks = (args.length > 1) ? args.join(' ').trim() : ''
         teks += '\n\n'
         for (let mem of groupMembers) {
         teks += `• @${mem.jid.split('@')[0]}\n`
         members_id.push(mem.jid)
         }
         mentions(teks, members_id, true)
         break
     case 'setname':
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply(mess.only.Badmin)
         fdhl.groupUpdateSubject(from, `${body.slice(9)}`)
         fdhl.sendMessage(from, `\`\`\`✓Sukses Mengganti Nama Group Menjadi\`\`\` *${body.slice(9)}*`, text, { quoted: ftrol })
         break
     case 'setdesc':
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply(mess.only.Badmin)
         fdhl.groupUpdateDescription(from, `${body.slice(9)}`)
         fdhl.sendMessage(from, `\`\`\`✓Sukses Mengganti Deskripsi Group\`\`\` *${groupMetadata.subject}* Menjadi: *${body.slice(9)}*`, text, { quoted: ftrol })
         break
     case 'setpp':
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply(mess.only.Badmin)
         media = await fdhl.downloadAndSaveMediaMessage(mek, './database/media_user')
         await fdhl.updateProfilePicture(from, media)
         reply(mess.wait)
         reply(`\`\`\`✓Sukses Mengganti Profil Group\`\`\` *${groupMetadata.subject}*`)
         break
     case 'hidetag':
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return reply(mess.only.admin)
         if (!isBotGroupAdmins) return reply(mess.only.Badmin)
         var value = body.slice(9)
         var group = await fdhl.groupMetadata(from)
         var member = group['participants']
         var mem = []
         member.map(async adm => {
         mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
         })
         var options = {
         text: value,
         contextInfo: { mentionedJid: mem },
         quoted: ftrol
         }
         fdhl.sendMessage(from, options, text)
         break

//━━━━━━━━━━━━━━━[ FITUR STICKER ]━━━━━━━━━━━━━━━━━//

     case 'attp':
         if (args.length == 0) return reply(`Example: ${prefix + command} Hai`)
         buffer = await getBuffer(`https://api.xteam.xyz/attp?file&text=${encodeURI(q)}`)
         fdhl.sendMessage(from, buffer, sticker, { quoted: ftrol })
         break
         case 'sticker':
         case 'stiker':
         case 's':
         case 'stickergif':
         if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
         const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
         const media = await fdhl.downloadAndSaveMediaMessage(encmedia, './database/media_user')
         ran = getRandom('.webp')
         await ffmpeg(`./${media}`)
         .input(media)
         .on('start', function (cmd) {
         console.log(`Started : ${cmd}`)
         })
         .on('error', function (err) {
         console.log(`Error : ${err}`)
         fs.unlinkSync(media)
         reply(mess.error.stick)
         })
         .on('end', function () {
         console.log('Finish')
         buffer = fs.readFileSync(ran)
         costum(buffer, sticker, Verived, `Subscribe Fadhil Graphy\nSubscriebe FebZabotz`)
         fs.unlinkSync(media)
         fs.unlinkSync(ran)
         })
         .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
         .toFormat('webp')
         .save(ran)
         } else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
         const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
         const media = await fdhl.downloadAndSaveMediaMessage(encmedia, './database/media_user')
         ran = getRandom('.webp')
         reply(mess.wait)
         await ffmpeg(`./${media}`)
         .inputFormat(media.split('.')[1])
         .on('start', function (cmd) {
         console.log(`Started : ${cmd}`)
         })
         .on('error', function (err) {
         console.log(`Error : ${err}`)
         fs.unlinkSync(media)
         tipe = media.endsWith('.mp4') ? 'video' : 'gif'
         reply(`❌ Gagal, pada saat mengkonversi ${tipe} ke stiker. pastikan untuk video yang dikirim tidak lebih dari 9 detik`)
         })
         .on('end', function () {
         console.log('Finish')
         costum(fs.readFileSync(ran), sticker, Verived, `~ Nih Dah Jadi Stiker gif nya`)
         fs.unlinkSync(media)
         fs.unlinkSync(ran)
         })
         .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
         .toFormat('webp')
         .save(ran)
         } else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
         const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
         const media = await fdhl.downloadAndSaveMediaMessage(encmedia, './database/media_user')
         ranw = getRandom('.webp')
         ranp = getRandom('.png')
         reply(mess.wait)
         keyrmbg = 'bcAvZyjYAjKkp1cmK8ZgQvWH'
         await removeBackgroundFromImageFile({ path: media, apiKey: keyrmbg, size: 'auto', type: 'auto', ranp }).then(res => {
         fs.unlinkSync(media)
         let buffer = Buffer.from(res.base64img, 'base64')
         fs.writeFileSync(ranp, buffer, (err) => {
         if (err) return reply('Gagal, Terjadi kesalahan, silahkan coba beberapa saat lagi.')
         })
         exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
         fs.unlinkSync(ranp)
         if (err) return reply(mess.error.stick)
         fdhl.sendMessage(from, fs.readFileSync(ranw), sticker, { quoted: ftrol })
         fs.unlinkSync(ranw)
         })
         })
         } else {
         reply(`Kirim gambar dengan caption ${prefix}sticker atau tag gambar yang sudah dikirim`)
         }
         break
     case 'toimg':
         if (!isQuotedSticker) return reply(' reply stickernya gan')
         encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
         media = await fdhl.downloadAndSaveMediaMessage(encmedia, './database/media_user')
         ran = getRandom('.png')
         exec(`ffmpeg -i ${media} ${ran}`, (err) => {
         fs.unlinkSync(media)
         if (err) return reply(' Gagal, pada saat mengkonversi sticker ke gambar ')
         buffer = fs.readFileSync(ran)
         costum(buffer, image, Verived, `Jangan Lupa donasi`)
         fs.unlinkSync(ran)
         })
         break
     case 'tomp3':
         fdhl.updatePresence(from, Presence.recording)
         if (!isQuotedVideo) return reply('Reply Video nya Tod')
         reply(mess.wait)
         encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
         media = await fdhl.downloadAndSaveMediaMessage(encmedia, './database/media_user')
         ran = getRandom('.mp4')
         exec(`ffmpeg -i ${media} ${ran}`, (err) => {
         fs.unlinkSync(media)
         if (err) return reply('Gagal, pada saat mengkonversi video ke mp3')
         bufferlkj = fs.readFileSync(ran)
         fdhl.sendMessage(from, bufferlkj, audio, { mimetype: 'audio/mp4', quoted: ftrol })
         fs.unlinkSync(ran)
         })
         break
     case 'tovideo':
         if (!isQuotedSticker) return reply('Reply stikernya')
         reply(mess.wait)
         anumedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
         anum = await fdhl.downloadAndSaveMediaMessage(anumedia, './database/media_user')
         ran = getRandom('.webp')
         exec(`ffmpeg -i ${anum} ${ran}`, (err) => {
         fs.unlinkSync(anum)
         buffer = fs.readFileSync(ran)
         fdhl.sendMessage(from, buffer, video, { quoted: ftrol, caption: 'Done... Jangan Lupa Subscribe Donasi' })
         fs.unlinkSync(ran)
         })
         break
     case 'donasi':
donasi = `┏━━━━━━━━━━━━━━━━━━━━
┃        DONASI FADHIL
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱❉ *DONASI YOK* ❉⊰━━✿
┃   
┣━⊱ *GOPAY*
┣⊱ 085849261085
┣━⊱ *DANA*
┣⊱ 085849261085
┣━⊱ *PULSA*
┣⊱ 085849261085
┃
┗━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━
┃         DONASI PEBRI
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱❉ *DONASI YOK* ❉⊰━━✿
┃   
┣━⊱ *GOPAY*
┣⊱ 085849261085
┣━⊱ *DANA*
┣⊱ 085849261085
┣━⊱ *PULSA*
┣⊱ 085849261085
┃
┗━━━━━━━━━━━━━━━━━━━`
reply(donasi)
break
//━━━━━━━━━━━━━━━[ FITUR OWNER ]━━━━━━━━━━━━━━━━━//

     case 'owner':
         members_ids = []
         for (let mem of groupMembers) {
         members_ids.push(mem.jid)
         }
         vcard2 = 'BEGIN:VCARD\n'
         + 'VERSION:3.0\n'
         + `FN:${ownername}\n`
         + `ORG: Creator ${ownername} ;\n`
         + `TEL;type=CELL;type=VOICE;waid=${owner}:${owner}\n`
         + 'END:VCARD'.trim()
         fdhl.sendMessage(from, {displayName: `Creator ${ownername}`, vcard: vcard2}, contact, 
         { quoted: ftrol, 
         })
         reply('TUHH NOMER OWNER KU')
         break
     case 'bc':
         if (!isOwner) return reply('LU BUKAN OWNER GBLOK')
         if (args.length < 1) return reply('.......')
         anu = await fdhl.chats.all()
         if (isMedia && !mek.message.videoMessage || isQuotedImage) {
         const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
         bc = await fdhl.downloadMediaMessage(encmedia)
         for (let _ of anu) {
         fdhl.sendMessage(_.jid, bc, image, { caption: `[ Ciko Bot\nIzin Broadcast ]\n\n${body.slice(4)}` })
         }
         reply('Suksess broadcast')
         } else {
         for (let _ of anu) {
         sendMess(_.jid, `[ *BOT BROADCAST* ]\n\n${body.slice(4)}`)
         }
         reply('Suksess broadcast')
         }
         break
     case 'report':
         const pesan = body.slice(8)
         if (pesan.length > 300) return pras.sendMessage(from, 'Maaf Teks Terlalu Panjang, Maksimal 300 Teks', text, { quoted: ftrol })
         var nomor = mek.participant
         const teks1 = `*[REPORT]*\nNomor : @${nomor.split("@s.whatsapp.net")[0]}\nPesan : ${pesan}`
         var options = {
         text: teks1,
         contextInfo: { mentionedJid: [nomor] },
         }
         fdhl.sendMessage(`6285157740529@s.whatsapp.net`, options, text, { quoted: ftrol })
         reply('Masalah Telah Di Laporkan Ke Owner BOT, Mohon Tunggu Untuk Proses Perbaikan')
         break
     default:
     if (isOwner) {
			     if (budy.startsWith('>')) {
				     console.log(color('[EVAL1]'), color(moment(mek.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`eval return`))
				     try {
					     let evaled = await eval(budy.slice(2))
					     if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
					     reply(`${evaled}`)
				     } catch (err) {
					     reply(`${err}`)
				     }
			     } else if (budy.startsWith('x')) {
				     console.log(color('[EVAL2]'), color(moment(mek.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`eval identy`))
				     try {
					     return fdhl.sendMessage(from, JSON.stringify(eval(budy.slice(2)), null, '\t'), text, { quoted: ftrol })
				     } catch (err) {
					     e = String(err)
					     reply(e)
				     }
			     }
		     }
		     }
	     } catch (e) {
         e = String(e)
         if (!e.includes("this.isZero") && !e.includes("jid")) {
	     console.log('Error : %s', color(e, 'red'))
             }
	     // console.log(e)
	     }
     }


	
    
